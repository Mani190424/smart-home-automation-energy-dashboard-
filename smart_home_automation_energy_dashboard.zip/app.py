
import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(layout="wide")
st.title("Smart Home Automation Energy Dashboard")

# Load data
df = pd.read_csv("processed_with_timestamp.csv", parse_dates=["Timestamp"])
df['Date'] = df['Timestamp'].dt.date

# Sidebar filters
with st.sidebar:
    st.header("Filters")
    start_date = st.date_input("Start Date", value=df['Date'].min())
    end_date = st.date_input("End Date", value=df['Date'].max())
    rooms = st.multiselect("Select Rooms", options=df['Room'].unique(), default=list(df['Room'].unique()))

# Filter data
filtered_df = df[(df['Date'] >= start_date) & (df['Date'] <= end_date) & (df['Room'].isin(rooms))]

# KPIs
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Power", f"{filtered_df['Energy_Consumption'].sum():.2f} kWh")
if "Temperature" in filtered_df.columns:
    avg_temp = filtered_df['Temperature'].mean()
    max_temp = filtered_df['Temperature'].max()
    min_temp = filtered_df['Temperature'].min()
else:
    avg_temp = max_temp = min_temp = None
col2.metric("Avg Temperature", f"{avg_temp:.2f} °C" if avg_temp else "No Data")
col3.metric("Max Temp", f"{max_temp:.2f} °C" if max_temp else "No Data")
col4.metric("Min Temp", f"{min_temp:.2f} °C" if min_temp else "No Data")

# Line chart: Power Usage Over Time
st.subheader("📈 Power Usage Over Time")
fig1 = px.line(filtered_df, x="Timestamp", y="Energy_Consumption", color="Room")
st.plotly_chart(fig1, use_container_width=True)

# Bar chart: Monthly Power Usage by Room
st.subheader("📊 Monthly Power Usage by Room")
filtered_df['Month'] = filtered_df['Timestamp'].dt.to_period("M").astype(str)
monthly_usage = filtered_df.groupby(["Month", "Room"])["Energy_Consumption"].sum().reset_index()
fig2 = px.bar(monthly_usage, x="Month", y="Energy_Consumption", color="Room", barmode="group")
st.plotly_chart(fig2, use_container_width=True)

# Pie chart: Power % by Room
st.subheader("🍕 Power Usage Share by Room")
room_usage = filtered_df.groupby("Room")["Energy_Consumption"].sum().reset_index()
fig3 = px.pie(room_usage, names="Room", values="Energy_Consumption", title="Power % by Room")
st.plotly_chart(fig3, use_container_width=True)
